var elementonoticia = JSON.parse(localStorage.getItem("noticia"))
  console.log(elementonoticia.titulo)
  "Por" +elementonoticia.autor + "g2 — Presidente Prudente"
document.getElementById("titulopgnoticia").innerText = elementonoticia.titulo
document.getElementsByClassName("imgMain")[0].src = "../assets/"+elementonoticia.url
document.getElementsByClassName("textoMain")[0].innerText = elementonoticia.conteudo
document.getElementsByClassName("criado")[0].innerText = "Por " +elementonoticia.autor + " — g2, Presidente Prudente"